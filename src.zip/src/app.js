const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const morgan = require('morgan');
const routes = require('./routes'); // Importar las rutas

// Cargar variables de entorno
dotenv.config();

const app = express();

// Middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Configuración de rutas
app.use('/api', routes); // Todas las rutas estarán bajo el prefijo /api

// Endpoint para health-check
app.get('/health', (req, res) => {
    res.status(200).json({ message: 'Server is running' });
});

// Manejo de errores
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send({ error: 'An error occurred!' });
});

module.exports = app;
