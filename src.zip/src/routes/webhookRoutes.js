const express = require('express');
const router = express.Router();
const webhookController = require('../controllers/webhookController'); // Importa el controlador

// Ruta de verificación del webhook
router.get('/webhook', webhookController.verifyWebhook);

// Ruta para recibir mensajes entrantes
router.post('/webhook', webhookController.receiveMessage); // Asegúrate de que receiveMessage esté definido

module.exports = router;
